/// <reference lib="webworker" />

import { InputReplay, normalizeInputScenario } from "../core/input-scenario";
import { evaluateExpression, evaluateWatch, MAX_WATCH_EXPRESSIONS } from "../core/expressions";
import { sha256Hex } from "../core/digest";
import { InstructionCoverage, type CoverageReport } from "../core/coverage";
import { Cpu8051 } from "../core/cpu";
import { Debugger8051, assertDebugAddress, assertWritableAddress, type DebugStop } from "../core/debugger";
import { opcodeMeta } from "../core/opcodes";
import { EmulatorFault, type EmulatorFaultData, type MemorySpace, type StepResult } from "../core/types";
import type { EmulatorCommand, EmulatorEvent } from "./protocol";

const scope = self as unknown as DedicatedWorkerGlobalScope;
const debugger8051 = new Debugger8051();
const coverage = new InstructionCoverage();
const postCoverage = (requestId: number): void => post({ type: "CoverageChanged", requestId, summary: coverage.summary() });

let replay: InputReplay | undefined;
let scenarioGeneration = 0;
const postScenario = (requestId: number, definitionChanged = false): void => post({ type:"ScenarioChanged", requestId, replay:replay?.view() ?? {active:false,delivered:[]}, definitionChanged, ...(definitionChanged && replay ? {scenario:replay.scenario} : {}) });
const requireManualInput = (): void => { if (replay?.active) invalid("请先取消输入重放再手工修改 CPU 或外部输入"); };

let cpu: Cpu8051 | undefined;
let firmware: { name: string; bytes: ArrayBuffer; digest?: Promise<string> } | undefined;
let running = false;
let runToken = 0;
let activeRequestId = 0;
let remainingSteps = 0;
let traceEnabled = false;
let lastStateAt = 0;
let lastSnapshotAt = 0;
let outTarget: { id: number; generation: number } | undefined;
let target: { address: number; reason: "RunToAddress" | "StepComplete"; sp?: number } | undefined;

const post = (event: EmulatorEvent): void => scope.postMessage(event);

const invalid = (message: string): never => {
  throw new EmulatorFault({ code: "INVALID_INPUT", message });
};

const assertInteger = (value: number, minimum: number, maximum: number, name: string): void => {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    invalid(`${name}必须是 ${minimum} 到 ${maximum} 的整数`);
  }
};

const assertTrace = (value: boolean): void => {
  if (typeof value !== "boolean") invalid("跟踪开关必须是布尔值");
};

const requireCpu = (): Cpu8051 => {
  return cpu ?? invalid("尚未加载固件");
};

const requireStopped = (): Cpu8051 => {
  const machine = requireCpu();
  if (running) invalid("请先暂停模拟器再编辑内存或寄存器");
  return machine;
};

const stopCurrentRun = (): void => {
  running = false;
  runToken += 1;
  target = undefined;
  outTarget = undefined;
};

const finishRun = (requestId: number, stop: DebugStop): void => {
  const machine = requireCpu();
  stopCurrentRun();
  debugger8051.stopped(stop);
  postScenario(requestId);
  if (coverage.enabled) postCoverage(requestId);
  post({ type: "Stopped", requestId, ...stop, state: machine.state(), snapshot: machine.snapshot() });
};

const faultData = (error: unknown): EmulatorFaultData =>
  error instanceof EmulatorFault
    ? error.data
    : { code: "INVALID_SNAPSHOT", message: error instanceof Error ? error.message : "未知模拟器错误" };

const postSerialOutput = (requestId: number): void => {
  const bytes = cpu?.drainSerialOutput() ?? [];
  if (bytes.length > 0) post({ type: "SerialOutput", requestId, bytes });
};

const reportFault = (requestId: number, error: unknown): void => {
  stopCurrentRun();
  debugger8051.stopped({ reason: "Paused" });
  if (replay) replay.active = false;
  postScenario(requestId);
  postSerialOutput(requestId);
  if (coverage.enabled) postCoverage(requestId);
  post({ type: "ExecutionFault", requestId, error: faultData(error), state: cpu?.state(), snapshot: cpu?.snapshot() });
};

const flushOutput = (requestId: number, trace: StepResult[], serial: number[]): void => {
  if (trace.length > 0) post({ type: "TraceBatch", requestId, trace });
  if (serial.length > 0) post({ type: "SerialOutput", requestId, bytes: serial });
};

const traceStep = (step: StepResult): StepResult => ({
  ...step,
  state: {
    ...step.state,
    peripherals: {
      ...step.state.peripherals,
      // Console history belongs in state updates and workspace snapshots.
      serial: { ...step.state.peripherals.serial, txOutput: [] },
    },
  },
});

const stepOutStop = (machine: Cpu8051): DebugStop | undefined => {
  const currentTarget = outTarget;
  if (!currentTarget) return undefined;
  const stack = machine.callStack.state(machine.memory);
  if (stack.generation !== currentTarget.generation) return { reason: "CallStackInvalidated", address: machine.pc };
  if (!stack.frames.some((frame) => frame.id === currentTarget.id)) return { reason: "StepComplete", address: machine.pc };
  return undefined;
};

const pump = (token: number): void => {
  if (!running || token !== runToken || !cpu) return;
  const machine = cpu;
  const trace: StepResult[] = [];
  const serial: number[] = [];
  const startedAt = performance.now();
  try {
    const chunkLimit = Math.min(10_000, remainingSteps);
    let stop: DebugStop | undefined;
    for (let executed = 0; executed < chunkLimit; executed += 1) {
      stop = stepOutStop(machine);
      if (stop) break;
      if (target?.address === machine.pc && (target.sp === undefined || target.sp === machine.state().sp)) {
        stop = { reason: target.reason, address: target.address };
        break;
      }
      if (replay?.active) replay.advance(machine);
      const watched = debugger8051.capture(machine.memory);
      const result = machine.step(() => {
        stop = debugger8051.beforeStep(machine.pc, expression => evaluateExpression(machine, expression));
        return !stop;
      });
      if (!result) break;
      if (coverage.enabled && result.kind === "instruction") coverage.record(result.pcBefore);
      remainingSteps -= 1;
      if (traceEnabled) {
        trace.push(traceStep(result));
        if (trace.length > 1000) trace.shift();
      }
      // Drain each step so trace states do not repeatedly copy a growing TX queue.
      serial.push(...machine.drainSerialOutput());
      stop = debugger8051.accessed(machine.operandAccesses) ?? debugger8051.changed(machine.memory, watched);
      if (stop) break;
      stop = stepOutStop(machine);
      if (stop) break;
      if (result.state.peripherals.powerMode === "power-down") {
        stop = { reason: "PowerDown", address: machine.pc };
        break;
      }
      // A reached target wins over the instruction budget at the same boundary.
      if (target?.address === machine.pc && (target.sp === undefined || target.sp === machine.state().sp)) {
        stop = { reason: target.reason, address: target.address };
        break;
      }
      if (performance.now() - startedAt >= 16) break;
    }
    flushOutput(activeRequestId, trace, serial);
    if (stop) {
      finishRun(activeRequestId, stop);
      return;
    }
    if (remainingSteps <= 0) {
      finishRun(activeRequestId, { reason: "StepLimitReached" });
      return;
    }

    const currentTime = performance.now();
    if (currentTime - lastStateAt >= 100) {
      postScenario(activeRequestId);
      post({ type: "StateChanged", requestId: activeRequestId, state: machine.state(), running: true });
      lastStateAt = currentTime;
    }
    if (currentTime - lastSnapshotAt >= 2000) {
      post({ type: "SnapshotCreated", requestId: activeRequestId, snapshot: machine.snapshot(), automatic: true });
      lastSnapshotAt = currentTime;
    }
    setTimeout(() => pump(token), 0);
  } catch (error) {
    // A later failing instruction must not discard successful instructions in this chunk.
    flushOutput(activeRequestId, trace, serial);
    reportFault(activeRequestId, error);
  }
};

const startRun = (
  requestId: number,
  maxSteps: number,
  trace: boolean,
  runTarget?: typeof target,
  bypassCurrent = false,
  frameTarget?: typeof outTarget,
): void => {
  assertInteger(maxSteps, 0, Number.MAX_SAFE_INTEGER, "执行步数");
  assertTrace(trace);
  const machine = requireCpu();
  scenarioGeneration += 1;
  stopCurrentRun();
  debugger8051.beginRun(machine.pc, bypassCurrent);
  activeRequestId = requestId;
  remainingSteps = maxSteps;
  traceEnabled = trace;
  target = runTarget;
  outTarget = frameTarget;
  running = true;
  lastStateAt = performance.now();
  lastSnapshotAt = lastStateAt;
  if (target?.address === machine.pc && target.sp === undefined) {
    finishRun(requestId, { reason: target.reason, address: target.address });
  } else if (remainingSteps === 0) {
    finishRun(requestId, { reason: "StepLimitReached" });
  } else {
    const token = runToken;
    setTimeout(() => pump(token), 0);
  }
};

const stepOnce = (requestId: number, trace: boolean): void => {
  stopCurrentRun();
  const machine = requireCpu();
  scenarioGeneration += 1;
  debugger8051.stopped({ reason: "StepComplete" });
  if (replay?.active) replay.advance(machine);
  const watched = debugger8051.capture(machine.memory);
  const step = machine.step();
  if (coverage.enabled && step.kind === "instruction") coverage.record(step.pcBefore);
  flushOutput(requestId, trace ? [traceStep(step)] : [], machine.drainSerialOutput());
  post({ type: "StateChanged", requestId, state: machine.state(), step, running: false });
  post({ type: "SnapshotCreated", requestId, snapshot: machine.snapshot(), automatic: false });
  finishRun(requestId, debugger8051.accessed(machine.operandAccesses) ?? debugger8051.changed(machine.memory, watched) ?? {
    reason: step.state.peripherals.powerMode === "power-down" ? "PowerDown" : "StepComplete",
  });
};

const postEditedState = (requestId: number): void => {
  const machine = requireCpu();
  post({ type: "StateChanged", requestId, state: machine.state(), running });
  post({ type: "SnapshotCreated", requestId, snapshot: machine.snapshot(), automatic: false });
};

const assertReadMemory = (space: MemorySpace, address: number, length: number): void => {
  if (!["code", "iram", "sfr", "xram"].includes(space)) invalid("内存空间无效");
  const minimum = space === "sfr" ? 0x80 : 0;
  const maximum = space === "iram" ? 0x7f : space === "sfr" ? 0xff : 0xffff;
  assertInteger(address, minimum, maximum, "内存地址");
  assertInteger(length, 0, maximum - minimum + 1, "读取长度");
  if (address + length > maximum + 1) invalid("读取范围超出内存空间");
};

scope.onmessage = (message: MessageEvent<EmulatorCommand>): void => {
  const command = message.data;
  const requestId = command && Number.isSafeInteger(command.requestId) && command.requestId >= 0 ? command.requestId : 0;
  let executing = false;
  try {
    if (!command || typeof command !== "object") invalid("模拟器命令无效");
    assertInteger(command.requestId, 0, Number.MAX_SAFE_INTEGER, "请求编号");
    switch (command.type) {
      case "InstallScenario": {
        requireStopped(); requireManualInput();
        const definition = normalizeInputScenario(command.scenario);
        const source = firmware!;
        const generation = ++scenarioGeneration;
        source.digest ??= sha256Hex(source.bytes).catch(error => { source.digest=undefined; throw error; });
        void source.digest.then(digest => {
          // A cancelled verification must not replace a newer definition or surface a late error.
          if (generation !== scenarioGeneration || source !== firmware || running) return;
          if (digest !== definition.firmwareSha256) throw new Error("输入场景固件 SHA-256 不匹配，当前工作区未改变");
          replay = new InputReplay(definition);
          postScenario(requestId,true);
          postEditedState(requestId);
        }).catch(error => {
          if (generation === scenarioGeneration && source === firmware)
            post({type:"CommandRejected",requestId,error:faultData(error),running});
        });
        return;
      }
      case "StartScenario": {
        requireStopped(); requireManualInput();
        if (!replay) invalid("请先导入并验证输入场景");
        scenarioGeneration += 1;
        stopCurrentRun();
        cpu = new Cpu8051(new Uint8Array(firmware!.bytes));
        cpu.captureOperandAccesses = debugger8051.observesOperands;
        debugger8051.resetHits(); coverage.clear(); postCoverage(requestId);
        replay!.start();
        finishRun(requestId,{reason:"Paused"});
        return;
      }
      case "CancelScenario":
        scenarioGeneration += 1;
        if (replay) replay.active = false;
        postScenario(requestId);
        return;
      case "ClearScenario":
        requireStopped(); requireManualInput();
        scenarioGeneration += 1; replay = undefined;
        postScenario(requestId,true); postEditedState(requestId);
        return;
      case "LoadFirmware":
      case "RestoreWorkspace": {
        if (!(command.bytes instanceof ArrayBuffer) || typeof command.name !== "string") invalid("固件命令无效");
        const loaded = new Cpu8051(new Uint8Array(command.bytes));
        if (command.type === "RestoreWorkspace") loaded.restore(command.snapshot);
        stopCurrentRun();
        debugger8051.resetHits();
        loaded.captureOperandAccesses = debugger8051.observesOperands;
        scenarioGeneration += 1; replay = undefined;
        cpu = loaded;
        firmware = { name: command.name, bytes: command.bytes.slice(0) };
        coverage.clear(true);
        postCoverage(requestId);
        postScenario(requestId);
        post({ type: "Ready", requestId, name: command.name, state: cpu.state(), snapshot: cpu.snapshot() });
        return;
      }
      case "Reset": {
        requireCpu().reset();
        scenarioGeneration += 1; replay?.reset();
        coverage.clear();
        postCoverage(requestId);
        debugger8051.resetHits();
        finishRun(requestId, { reason: "Paused" });
        return;
      }
      case "Step":
        assertTrace(command.trace);
        requireCpu();
        executing = true;
        stepOnce(requestId, command.trace);
        return;
      case "Run":
        startRun(requestId, command.maxSteps, command.trace);
        return;
      case "RunToAddress":
        assertDebugAddress(command.address);
        startRun(requestId, command.maxSteps, command.trace, { address: command.address, reason: "RunToAddress" });
        return;
      case "StepOver": {
        assertInteger(command.maxSteps, 0, Number.MAX_SAFE_INTEGER, "执行步数");
        assertTrace(command.trace);
        const machine = requireCpu();
        const opcode = machine.memory.readCode(machine.pc);
        if (command.maxSteps === 0) {
          finishRun(requestId, { reason: "StepLimitReached" });
        } else if (opcode === 0x12 || (opcode & 0x1f) === 0x11) {
          const address = (machine.pc + opcodeMeta(opcode).length) & 0xffff;
          startRun(requestId, command.maxSteps, command.trace, { address, reason: "StepComplete", sp: machine.state().sp }, true);
        } else {
          executing = true;
          stepOnce(requestId, command.trace);
        }
        return;
      }
      case "StepOut": {
        assertInteger(command.maxSteps, 0, Number.MAX_SAFE_INTEGER, "执行步数");
        assertTrace(command.trace);
        const machine = requireStopped();
        const stack = machine.callStack.state(machine.memory);
        const frame = stack.frames.at(-1);
        if (!frame) invalid("没有可验证的调用帧，无法跳出；请先执行调用或中断进入");
        startRun(requestId, command.maxSteps, command.trace, undefined, true, { id: frame!.id, generation: stack.generation });
        return;
      }
      case "Pause":
        finishRun(requestId, { reason: "Paused" });
        return;
      case "SetDebugConfig": {
        const config = debugger8051.setConfig(command);
        if (cpu) cpu.captureOperandAccesses = debugger8051.observesOperands;
        post({ type: "DebugConfigChanged", requestId, ...config });
        return;
      }
      case "WriteMemory": {
        requireManualInput();
        assertWritableAddress(command.space, command.address);
        assertInteger(command.value, 0, 0xff, "内存值");
        requireStopped().writeMemory(command.space, command.address, command.value);
        postEditedState(requestId);
        return;
      }
      case "SetRegister": {
        requireManualInput();
        if (typeof command.name !== "string") invalid("寄存器名称无效");
        assertInteger(command.value, 0, 0xffff, "寄存器值");
        requireStopped().setRegister(command.name, command.value);
        if (command.name.toUpperCase() === "PC") debugger8051.resetHits();
        postEditedState(requestId);
        return;
      }
      case "SetPortInput":
        requireManualInput();
        assertInteger(command.port, 0, 3, "GPIO 端口");
        assertInteger(command.value, 0, 0xff, "GPIO 输入值");
        requireCpu().setPortInput(command.port, command.value);
        postEditedState(requestId);
        return;
      case "ReceiveSerial":
        requireManualInput();
        assertInteger(command.value, 0, 0xff, "串口接收值");
        if (command.ninthBit !== undefined && typeof command.ninthBit !== "boolean") invalid("串口第九位必须是布尔值");
        requireCpu().receiveSerial(command.value, command.ninthBit);
        postEditedState(requestId);
        return;
      case "SetCoverage":
        requireCpu();
        if (typeof command.enabled !== "boolean") invalid("覆盖统计开关必须是布尔值");
        coverage.setEnabled(command.enabled);
        postCoverage(requestId);
        return;
      case "ClearCoverage":
        requireCpu();
        coverage.clear();
        postCoverage(requestId);
        return;
      case "CreateCoverageReport": {
        const machine = requireCpu();
        const source = firmware!;
        // Copy every mutable field synchronously between execution chunks, before hashing.
        const sample: Omit<CoverageReport, "firmware"> = {
          format: "emuc51-instruction-coverage", version: 1, scope: "successful-instruction-starts",
          capturedAt: new Date().toISOString(), pc: machine.pc, steps: machine.state().steps,
          summary: coverage.summary(), entries: coverage.entries(),
        };
        source.digest ??= sha256Hex(source.bytes);
        void source.digest.then(sha256 => {
          // Clear, reset, mode changes and replacement invalidate an in-flight report.
          if (source !== firmware || sample.summary.epoch !== coverage.summary().epoch) return;
          post({ type: "CoverageReportCreated", requestId, report: {
            ...sample, firmware: { name: source.name, sha256, byteLength: source.bytes.byteLength },
          } });
        }).catch(error => {
          source.digest = undefined;
          if (source === firmware && sample.summary.epoch === coverage.summary().epoch)
            post({ type: "CommandRejected", requestId, error: faultData(error), running });
        });
        return;
      }
      case "ReadCoverage": {
        requireCpu();
        if (!Array.isArray(command.addresses) || command.addresses.length > 256) invalid("覆盖查询最多 256 个 CODE 地址");
        for (const address of command.addresses) assertDebugAddress(address);
        post({ type: "CoverageData", requestId, summary: coverage.summary(), addresses: command.addresses, counts: coverage.read(command.addresses) });
        return;
      }
      case "EvaluateExpressions": {
        if (!Array.isArray(command.expressions) || command.expressions.length > MAX_WATCH_EXPRESSIONS ||
            Array.from(command.expressions).some((expression) => typeof expression !== "string")) invalid("观察列表须为最多 32 项的字符串数组");
        const machine = requireCpu();
        const results = evaluateWatch(machine, command.expressions);
        post({ type: "WatchResults", requestId, results, pc: machine.pc, steps: machine.state().steps });
        return;
      }
      case "ReadMemory": {
        assertReadMemory(command.space, command.address, command.length);
        const bytes = requireCpu().readMemory(command.space, command.address, command.length);
        post({ type: "MemoryData", requestId, space: command.space, address: command.address, bytes });
        return;
      }
      case "CreateSnapshot":
        post({ type: "SnapshotCreated", requestId, snapshot: requireCpu().snapshot(), automatic: false });
        return;
      default:
        invalid("未知模拟器命令");
    }
  } catch (error) {
    if (executing) reportFault(requestId, error);
    else post({ type: "CommandRejected", requestId, error: faultData(error), running });
  }
};

export {};
