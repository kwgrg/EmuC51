import type { InputScenario, ReplayView } from "../core/input-scenario";
import type { OperandAccess } from "../core/operand-access";
import type { CoverageReport, CoverageSummary } from "../core/coverage";
import type { WatchResult } from "../core/expressions";
import type {
  CpuSnapshot,
  CpuViewState,
  EmulatorFaultData,
  MemorySpace,
  StepResult,
} from "../core/types";
import type { DebugConfig, DebugStopReason, WatchpointChange, WritableMemorySpace } from "../core/debugger";

interface CommandBase {
  requestId: number;
}

export interface LoadFirmwareCommand extends CommandBase {
  type: "LoadFirmware";
  name: string;
  bytes: ArrayBuffer;
}

export interface RestoreWorkspaceCommand extends CommandBase {
  type: "RestoreWorkspace";
  name: string;
  bytes: ArrayBuffer;
  snapshot: CpuSnapshot;
}

export interface ResetCommand extends CommandBase {
  type: "Reset";
}

export interface StepCommand extends CommandBase {
  type: "Step";
  trace: boolean;
}

export interface RunCommand extends CommandBase {
  type: "Run";
  maxSteps: number;
  trace: boolean;
}

export interface RunToAddressCommand extends CommandBase {
  type: "RunToAddress";
  address: number;
  maxSteps: number;
  trace: boolean;
}

export interface StepOverCommand extends CommandBase {
  type: "StepOver";
  maxSteps: number;
  trace: boolean;
}

export interface StepOutCommand extends CommandBase {
  type: "StepOut";
  maxSteps: number;
  trace: boolean;
}

export interface SetDebugConfigCommand extends CommandBase, DebugConfig {
  type: "SetDebugConfig";
}

export interface WriteMemoryCommand extends CommandBase {
  type: "WriteMemory";
  space: WritableMemorySpace;
  address: number;
  value: number;
}

export interface SetRegisterCommand extends CommandBase {
  type: "SetRegister";
  name: string;
  value: number;
}

export interface SetPortInputCommand extends CommandBase {
  type: "SetPortInput";
  port: number;
  value: number;
}

export interface ReceiveSerialCommand extends CommandBase {
  type: "ReceiveSerial";
  value: number;
  ninthBit?: boolean;
}

export interface PauseCommand extends CommandBase {
  type: "Pause";
}

export interface ReadMemoryCommand extends CommandBase {
  type: "ReadMemory";
  space: MemorySpace;
  address: number;
  length: number;
}

export interface CreateSnapshotCommand extends CommandBase {
  type: "CreateSnapshot";
}

export interface EvaluateExpressionsCommand extends CommandBase {
  type: "EvaluateExpressions";
  expressions: string[];
}

export type EmulatorCommand =
  | { type: "InstallScenario"; requestId: number; scenario: InputScenario }
  | { type: "StartScenario" | "CancelScenario" | "ClearScenario"; requestId: number }
  | { type: "CreateCoverageReport"; requestId: number }
  | { type: "SetCoverage"; requestId: number; enabled: boolean }
  | { type: "ClearCoverage"; requestId: number }
  | { type: "ReadCoverage"; requestId: number; addresses: number[] }
  | EvaluateExpressionsCommand
  | LoadFirmwareCommand
  | RestoreWorkspaceCommand
  | ResetCommand
  | StepCommand
  | RunCommand
  | RunToAddressCommand
  | StepOverCommand
  | StepOutCommand
  | SetDebugConfigCommand
  | WriteMemoryCommand
  | SetRegisterCommand
  | SetPortInputCommand
  | ReceiveSerialCommand
  | PauseCommand
  | ReadMemoryCommand
  | CreateSnapshotCommand;

export type EmulatorEvent =
  | { type: "ScenarioChanged"; requestId: number; replay: ReplayView; definitionChanged: boolean; scenario?: InputScenario }
  | { type: "CoverageReportCreated"; requestId: number; report: CoverageReport }
  | { type: "CoverageChanged"; requestId: number; summary: CoverageSummary }
  | { type: "CoverageData"; requestId: number; summary: CoverageSummary; addresses: number[]; counts: number[] }
  | { type: "WatchResults"; requestId: number; results: WatchResult[]; pc: number; steps: number }
  | ({ type: "DebugConfigChanged"; requestId: number } & DebugConfig)
  | { type: "SerialOutput"; requestId: number; bytes: number[] }
  | { type: "CommandRejected"; requestId: number; error: EmulatorFaultData; running: boolean }
  | {
      type: "Ready";
      requestId: number;
      name: string;
      state: CpuViewState;
      snapshot: CpuSnapshot;
    }
  | {
      type: "StateChanged";
      requestId: number;
      state: CpuViewState;
      step?: StepResult;
      running: boolean;
    }
  | {
      type: "TraceBatch";
      requestId: number;
      trace: StepResult[];
    }
  | {
      type: "MemoryData";
      requestId: number;
      space: MemorySpace;
      address: number;
      bytes: Uint8Array;
    }
  | {
      type: "SnapshotCreated";
      requestId: number;
      snapshot: CpuSnapshot;
      automatic: boolean;
    }
  | {
      type: "Stopped";
      requestId: number;
      reason: DebugStopReason;
      address?: number;
      watchpoint?: WatchpointChange;
      accesses?: OperandAccess[];
      conditionError?: { expression: string; message: string };
      state: CpuViewState;
      snapshot: CpuSnapshot;
    }
  | {
      type: "ExecutionFault";
      requestId: number;
      error: EmulatorFaultData;
      state?: CpuViewState;
      snapshot?: CpuSnapshot;
    };
