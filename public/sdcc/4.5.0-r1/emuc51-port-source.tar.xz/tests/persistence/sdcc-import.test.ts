import { readFileSync } from "node:fs";
import { webcrypto } from "node:crypto";
import { afterAll, beforeAll, expect, it, vi } from "vitest";
import { sdccFixture } from "../fixtures/sdcc-fixture";
import { importSdccFiles } from "../../src/persistence/sdcc-import";
import { verifySdccDebug } from "../../src/core/sdcc-debug";
import { exportWorkspace, importWorkspace } from "../../src/persistence/transfer";
import { normalizeWorkspaceSettings } from "../../src/persistence/db";
import { workspaceFixture } from "./fixtures";
import { Cpu8051 } from "../../src/core/cpu";
beforeAll(() => vi.stubGlobal("crypto", webcrypto));
afterAll(() => vi.unstubAllGlobals());
const data = sdccFixture();
const files = () => [{ name: "emuc51-sdcc.json", text: JSON.stringify(data.manifest) }, ...(["source", "ihx", "cdb"] as const).map(key => ({ name: data.manifest.files[key].name, text: data[key] }))].map(({ name, text }) => ({ name, size: new TextEncoder().encode(text).length, arrayBuffer: async () => new TextEncoder().encode(text).buffer }) as File);
it("imports four files in any order and rejects missing/duplicate/mismatched files", async () => {
  expect((await importSdccFiles(files().reverse())).locations).toHaveLength(5);
  await expect(importSdccFiles(files().slice(1))).rejects.toThrow("四个");
  const duplicate = files(); duplicate[0] = duplicate[1]!;
  await expect(importSdccFiles(duplicate)).rejects.toThrow("四个");
  const renamed = files(); Object.assign(renamed[1]!, { name: "other.c" });
  await expect(importSdccFiles(renamed)).rejects.toThrow();
  const oversize = files(); Object.assign(oversize[2]!, { size: 256 * 1024 + 1 });
  await expect(importSdccFiles(oversize)).rejects.toThrow("256 KiB");
});
it("round-trips verified source debug data and rejects tampering before workspace replacement", async () => {
  const verified = await verifySdccDebug(data);
  const record = workspaceFixture();
  record.firmware = { ...record.firmware, bytes: verified.firmware, sha256: verified.firmwareSha256 };
  record.cpu = new Cpu8051(new Uint8Array(verified.firmware)).snapshot(); record.settings.sdccDebug = data;
  const text = exportWorkspace(record);
  expect((await importWorkspace(text)).settings.sdccDebug).toEqual(data);
  const stale = JSON.parse(text); stale.settings.sdccDebug.source += "\n";
  await expect(importWorkspace(JSON.stringify(stale))).rejects.toThrow("SHA-256");
  const different = workspaceFixture(); different.settings.sdccDebug = data;
  await expect(importWorkspace(exportWorkspace(different))).rejects.toThrow("当前固件");
});
it("does not allow concurrent ASM and SDCC firmware bindings", () => {
  expect(normalizeWorkspaceSettings({ ...workspaceFixture().settings, sdccDebug: data, asmProject: { name: "main.asm", source: "NOP" }, asmBinding: { assembler: "emuc51-asm-1", sourceSha256: "a".repeat(64), firmwareSha256: "b".repeat(64) } })).toBeUndefined();
});

it("imports a bounded mixed package and persists every source/header atomically", async () => {
  const text = readFileSync("tests/fixtures/sdcc-mixed/emuc51-project.build.json", "utf8");
  const bytes = new TextEncoder().encode(text);
  const file = { name: "emuc51-project.build.json", size: bytes.length, arrayBuffer: async () => bytes.buffer } as File;
  const verified = await importSdccFiles([file]);
  const record = workspaceFixture(); record.firmware = { ...record.firmware, bytes: verified.firmware, sha256: verified.firmwareSha256 };
  record.cpu = new Cpu8051(new Uint8Array(verified.firmware)).snapshot(); record.settings.sdccDebug = verified.data;
  const restored = await importWorkspace(exportWorkspace(record));
  expect(restored.settings.sdccDebug).toEqual(verified.data);
  const changed = JSON.parse(exportWorkspace(record)); changed.settings.sdccDebug.inputs[3].text += "\n";
  await expect(importWorkspace(JSON.stringify(changed))).rejects.toThrow("SHA-256");
  await expect(importSdccFiles([{ ...file, size: 2 * 1024 * 1024 + 1 } as File])).rejects.toThrow("2 MiB");
});

it("imports a downloaded single-file browser bundle and rejects altered source or a false mixed-package name", async () => {
  const file = (value: unknown, name = "emuc51-browser.build.json") => {
    const bytes = new TextEncoder().encode(JSON.stringify(value));
    return { name, size: bytes.length, arrayBuffer: async () => bytes.buffer } as File;
  };
  expect((await importSdccFiles([file(data)])).data).toEqual(data);
  await expect(importSdccFiles([file({ ...data, source: data.source + "\n" })])).rejects.toThrow("SHA-256");
  await expect(importSdccFiles([file(data, "emuc51-project.build.json")])).rejects.toThrow("版本 2");
});
